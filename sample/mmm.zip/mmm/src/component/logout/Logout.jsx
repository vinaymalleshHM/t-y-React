import React, { Component } from 'react'

export default class Logout extends Component {
    render() {
        return (
            <>
                
            <h1>Please login</h1>
      
            </>
        )
    }
}
